package com.shahid.gex

import java.time.Duration
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sqrt

object GexCalculator {
    private val NY = ZoneId.of("America/New_York")
    private const val RATE = 0.04
    private const val MIN_PER_YEAR = 525_600.0

    /**
     * GEX per contract = gamma * OI * 100 * spot^2 * 0.01  (calls +, puts -).
     * Current-spot figures use Cboe's own gamma. The gamma flip is found by re-pricing
     * every contract with Black-Scholes (from Cboe's IV) across a grid of spot levels
     * and locating where total GEX crosses zero.
     */
    fun compute(chain: Chain, filter: ExpFilter, windowPct: Double = 0.04): GexResult {
        val spot = chain.spot
        val now = ZonedDateTime.now(NY)
        val today = now.toLocalDate()
        // After the 4:15pm ET close, today's expiries are done
        val cutoff = if (now.toLocalTime() >= LocalTime.of(16, 15)) today.plusDays(1) else today
        val live = chain.options.filter { !it.expiry.isBefore(cutoff) }
        val first = live.minOfOrNull { it.expiry } ?: cutoff
        val sel = when (filter) {
            ExpFilter.ZERO -> live.filter { it.expiry == first }
            ExpFilter.WEEK -> live.filter { !it.expiry.isAfter(first.plusDays(7)) }
            ExpFilter.ALL -> live
        }.filter { abs(it.strike / spot - 1.0) <= 0.15 }

        val k = spot * spot * 0.01 * 100.0
        val calls = HashMap<Double, Double>()
        val puts = HashMap<Double, Double>()
        for (o in sel) {
            val g = o.gamma * o.oi * k
            if (o.isCall) calls[o.strike] = (calls[o.strike] ?: 0.0) + g
            else puts[o.strike] = (puts[o.strike] ?: 0.0) - g
        }

        val byStrike = (calls.keys + puts.keys).sorted()
            .map { StrikeGex(it, calls[it] ?: 0.0, puts[it] ?: 0.0) }

        val total = byStrike.sumOf { it.net }
        val callWall = byStrike.maxByOrNull { it.call }?.takeIf { it.call > 0 }?.strike
        val putWall = byStrike.minByOrNull { it.put }?.takeIf { it.put < 0 }?.strike
        val near = byStrike.filter { abs(it.strike / spot - 1.0) <= windowPct }

        val profile = profile(sel, spot, now)
        val flip = zeroCrossing(profile, spot) ?: strikeCumulativeFlip(byStrike, spot)

        return GexResult(spot, near, total, flip, callWall, putWall, profile)
    }

    private fun bsGamma(s: Double, k: Double, iv: Double, t: Double): Double {
        val sq = iv * sqrt(t)
        val d1 = (ln(s / k) + (RATE + 0.5 * iv * iv) * t) / sq
        return exp(-0.5 * d1 * d1) / sqrt(2.0 * PI) / (s * sq)
    }

    private fun profile(opts: List<Opt>, spot: Double, now: ZonedDateTime): List<ProfilePt> {
        val usable = opts.filter { it.iv > 0.0 }
        if (usable.isEmpty()) return emptyList()
        val n = usable.size
        val strikes = DoubleArray(n)
        val ivs = DoubleArray(n)
        val ts = DoubleArray(n)
        val weights = DoubleArray(n) // sign * OI * 100
        for (i in 0 until n) {
            val o = usable[i]
            strikes[i] = o.strike
            ivs[i] = o.iv
            val close = o.expiry.atTime(16, 0).atZone(NY)
            ts[i] = max(Duration.between(now, close).toMinutes().toDouble(), 10.0) / MIN_PER_YEAR
            weights[i] = (if (o.isCall) 1.0 else -1.0) * o.oi * 100.0
        }
        val steps = 60
        val lo = spot * 0.90
        val hi = spot * 1.10
        return (0..steps).map { j ->
            val s = lo + (hi - lo) * j / steps
            var sum = 0.0
            for (i in 0 until n) sum += weights[i] * bsGamma(s, strikes[i], ivs[i], ts[i])
            ProfilePt(s, sum * s * s * 0.01)
        }
    }

    private fun zeroCrossing(p: List<ProfilePt>, spot: Double): Double? {
        val xs = ArrayList<Double>()
        for (i in 1 until p.size) {
            val a = p[i - 1]
            val b = p[i]
            if ((a.gex < 0 && b.gex >= 0) || (a.gex > 0 && b.gex <= 0)) {
                xs += a.spot + (b.spot - a.spot) * (-a.gex) / (b.gex - a.gex)
            }
        }
        return xs.minByOrNull { abs(it - spot) }
    }

    private fun strikeCumulativeFlip(rows: List<StrikeGex>, spot: Double): Double? {
        var cum = 0.0
        val xs = ArrayList<Double>()
        for (i in rows.indices) {
            val prev = cum
            cum += rows[i].net
            if (i > 0 && prev != cum && (prev < 0 && cum >= 0 || prev > 0 && cum <= 0)) {
                val s0 = rows[i - 1].strike
                val s1 = rows[i].strike
                xs += s0 + (s1 - s0) * (-prev) / (cum - prev)
            }
        }
        return xs.minByOrNull { abs(it - spot) }
    }
}
