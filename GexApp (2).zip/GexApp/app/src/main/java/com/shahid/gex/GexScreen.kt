package com.shahid.gex

import android.graphics.Paint as AndroidPaint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.abs
import kotlin.math.max

private val Green = Color(0xFF2E7D32)
private val Red = Color(0xFFC62828)
private val Amber = Color(0xFFFFB300)
private val Blue = Color(0xFF1E88E5)

@Composable
fun GexTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme(),
        content = content,
    )
}

private fun px(v: Double) = if (v % 1.0 == 0.0) "%,.0f".format(v) else "%,.2f".format(v)

private fun money(v: Double): String {
    val a = abs(v)
    val s = if (v < 0) "-" else ""
    return when {
        a >= 1e9 -> "$s$${"%.2f".format(a / 1e9)}B"
        a >= 1e6 -> "$s$${"%.1f".format(a / 1e6)}M"
        else -> "$s$${"%,.0f".format(a)}"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GexScreen(vm: GexViewModel = viewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()
    var custom by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Gamma Exposure") },
                actions = { TextButton(onClick = { vm.refreshNow() }) { Text("Refresh") } },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("SPX", "SPY", "QQQ", "NDX", "IWM").forEach { t ->
                    FilterChip(selected = s.ticker == t, onClick = { vm.setTicker(t) }, label = { Text(t) })
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = custom,
                    onValueChange = { custom = it.uppercase() },
                    label = { Text("Other ticker") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                Button(onClick = { vm.setTicker(custom) }) { Text("Go") }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ExpFilter.values().forEach { f ->
                    FilterChip(selected = s.filter == f, onClick = { vm.setFilter(f) }, label = { Text(f.label) })
                }
            }

            if (s.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            s.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

            val r = s.result
            if (r != null) {
                Text(
                    "${s.ticker}  spot ${px(r.spot)}  ·  Cboe delayed (~15 min)  ·  ${s.chain?.timestamp.orEmpty()}",
                    style = MaterialTheme.typography.bodySmall,
                )
                if (s.chain?.fromCache == true) {
                    Text("Showing last saved snapshot, refreshing…", style = MaterialTheme.typography.bodySmall, color = Amber)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat(
                        "Net GEX / 1% move", money(r.totalGex),
                        if (r.totalGex >= 0) "Dampening regime" else "Amplifying regime",
                        if (r.totalGex >= 0) Green else Red, Modifier.weight(1f),
                    )
                    Stat(
                        "Gamma flip", r.flip?.let(::px) ?: "n/a",
                        r.flip?.let { if (r.spot >= it) "Spot above flip" else "Spot below flip" } ?: "",
                        Blue, Modifier.weight(1f),
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat("Call wall", r.callWall?.let(::px) ?: "n/a", "Largest +GEX strike", Green, Modifier.weight(1f))
                    Stat("Put wall", r.putWall?.let(::px) ?: "n/a", "Largest -GEX strike", Red, Modifier.weight(1f))
                }
                Text("GEX by strike", style = MaterialTheme.typography.titleSmall)
                GexChart(r)
                Text("Total GEX if spot moves (re-priced)", style = MaterialTheme.typography.titleSmall)
                ProfileChart(r)
                Text(
                    "Green = call GEX · Red = put GEX · Amber = spot · Blue = gamma flip (re-priced with Black-Scholes from Cboe IV).\n" +
                        "Assumes dealers are long calls / short puts, so treat levels as an estimate.",
                    style = MaterialTheme.typography.bodySmall,
                )
            } else if (!s.loading && s.error == null) {
                Text("No data")
            }
        }
    }
}

@Composable
private fun Stat(title: String, value: String, sub: String, accent: Color, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium)
            Text(value, style = MaterialTheme.typography.headlineSmall, color = accent)
            if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun GexChart(r: GexResult) {
    val rows = r.strikes.sortedByDescending { it.strike }
    if (rows.isEmpty()) {
        Text("No open interest for this filter.")
        return
    }
    val rowH = 18.dp
    val maxAbs = rows.maxOf { max(abs(it.call), abs(it.put)) }.coerceAtLeast(1.0)
    val textArgb = MaterialTheme.colorScheme.onSurface.toArgb()

    Canvas(Modifier.fillMaxWidth().height(rowH * rows.size)) {
        val rh = rowH.toPx()
        val labelW = 64.dp.toPx()
        val cx = labelW + (size.width - labelW) / 2f
        val half = (size.width - labelW) / 2f - 4.dp.toPx()
        val pad = 2.dp.toPx()

        val labelPaint = AndroidPaint().apply { color = textArgb; textSize = 10.sp.toPx(); isAntiAlias = true }
        val spotPaint = AndroidPaint().apply { color = Amber.toArgb(); textSize = 10.sp.toPx(); isAntiAlias = true; isFakeBoldText = true }
        val flipPaint = AndroidPaint().apply { color = Blue.toArgb(); textSize = 10.sp.toPx(); isAntiAlias = true; isFakeBoldText = true }

        fun yOf(p: Double): Float {
            if (p >= rows.first().strike) return rh / 2
            if (p <= rows.last().strike) return rows.size * rh - rh / 2
            for (i in 0 until rows.size - 1) {
                val a = rows[i].strike
                val b = rows[i + 1].strike
                if (p <= a && p >= b) return ((i + (a - p) / (a - b)).toFloat() + 0.5f) * rh
            }
            return rh / 2
        }

        rows.forEachIndexed { i, row ->
            val y = i * rh
            val cw = (abs(row.call) / maxAbs * half).toFloat()
            val pw = (abs(row.put) / maxAbs * half).toFloat()
            drawRect(Green, Offset(cx, y + pad), Size(cw, rh - 2 * pad))
            drawRect(Red, Offset(cx - pw, y + pad), Size(pw, rh - 2 * pad))
        }
        drawLine(Color.Gray, Offset(cx, 0f), Offset(cx, size.height), strokeWidth = 1.dp.toPx())

        drawIntoCanvas { c ->
            rows.forEachIndexed { i, row ->
                c.nativeCanvas.drawText(px(row.strike), 0f, i * rh + rh * 0.7f, labelPaint)
            }
        }

        val dash = PathEffect.dashPathEffect(floatArrayOf(14f, 8f))
        val sy = yOf(r.spot)
        drawLine(Amber, Offset(labelW, sy), Offset(size.width, sy), strokeWidth = 2.dp.toPx(), pathEffect = dash)
        drawIntoCanvas { it.nativeCanvas.drawText("SPOT", size.width - 40.dp.toPx(), sy - 3.dp.toPx(), spotPaint) }

        r.flip?.let { f ->
            val fy = yOf(f)
            drawLine(Blue, Offset(labelW, fy), Offset(size.width, fy), strokeWidth = 2.dp.toPx(), pathEffect = dash)
            drawIntoCanvas { it.nativeCanvas.drawText("FLIP", size.width - 40.dp.toPx(), fy - 3.dp.toPx(), flipPaint) }
        }
    }
}


@Composable
fun ProfileChart(r: GexResult) {
    val pts = r.profile
    if (pts.size < 2) {
        Text("No IV data for the profile.", style = MaterialTheme.typography.bodySmall)
        return
    }
    val textArgb = MaterialTheme.colorScheme.onSurface.toArgb()
    val maxAbs = pts.maxOf { abs(it.gex) }.coerceAtLeast(1.0)
    Canvas(Modifier.fillMaxWidth().height(160.dp)) {
        val w = size.width
        val h = size.height
        val x0 = pts.first().spot
        val x1 = pts.last().spot
        fun xOf(p: Double) = ((p - x0) / (x1 - x0) * w).toFloat()
        fun yOf(g: Double) = (h / 2f - (g / maxAbs * (h / 2f - 12.dp.toPx())).toFloat())

        drawLine(Color.Gray, Offset(0f, h / 2f), Offset(w, h / 2f), strokeWidth = 1.dp.toPx())

        val path = Path()
        pts.forEachIndexed { i, p ->
            if (i == 0) path.moveTo(xOf(p.spot), yOf(p.gex)) else path.lineTo(xOf(p.spot), yOf(p.gex))
        }
        drawPath(path, Blue, style = Stroke(width = 2.dp.toPx()))

        val dash = PathEffect.dashPathEffect(floatArrayOf(14f, 8f))
        if (r.spot in x0..x1) {
            drawLine(Amber, Offset(xOf(r.spot), 0f), Offset(xOf(r.spot), h), strokeWidth = 2.dp.toPx(), pathEffect = dash)
        }
        r.flip?.let { f ->
            if (f in x0..x1) {
                drawLine(Red, Offset(xOf(f), 0f), Offset(xOf(f), h), strokeWidth = 2.dp.toPx(), pathEffect = dash)
            }
        }
        val paint = AndroidPaint().apply { color = textArgb; textSize = 10.sp.toPx(); isAntiAlias = true }
        drawIntoCanvas { c ->
            c.nativeCanvas.drawText(px(x0), 0f, h - 2.dp.toPx(), paint)
            c.nativeCanvas.drawText(px(x1), w - 48.dp.toPx(), h - 2.dp.toPx(), paint)
            c.nativeCanvas.drawText(money(maxAbs), 0f, 12.dp.toPx(), paint)
        }
    }
}
