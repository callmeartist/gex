package com.shahid.gex

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.format.DateTimeFormatter

/**
 * Cboe delayed-quotes options chain (cdn.cboe.com). Real Cboe data: per-contract
 * open interest, IV and Cboe-computed greeks. Quotes are delayed ~15 minutes; open
 * interest is the prior-day figure (updated once per day), which is how every GEX
 * tool works.
 */
object CboeRepository {
    private val INDEXES = setOf("SPX", "NDX", "RUT", "XSP", "VIX", "DJX", "OEX")
    private val SYMBOL = Regex("^(.+?)(\\d{6})([CP])(\\d{8})$")
    private val DATE = DateTimeFormatter.ofPattern("yyMMdd")

    private fun endpoint(ticker: String): String {
        val sym = if (ticker in INDEXES) "_$ticker" else ticker
        return "https://cdn.cboe.com/api/global/delayed_quotes/options/$sym.json"
    }

    suspend fun fetch(ticker: String, cacheDir: File): Chain = withContext(Dispatchers.IO) {
        var lastErr: Exception? = null
        repeat(3) { attempt ->
            try {
                val chain = download(ticker)
                runCatching { save(ticker, chain, cacheDir) }
                return@withContext chain
            } catch (e: Exception) {
                lastErr = e
                if (attempt < 2) Thread.sleep(1500L * (attempt + 1))
            }
        }
        throw lastErr ?: IllegalStateException("Download failed")
    }

    private fun download(ticker: String): Chain {
        val conn = (URL(endpoint(ticker)).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15_000
            readTimeout = 45_000
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) GexApp/1.0")
            setRequestProperty("Accept", "application/json")
        }
        try {
            when (conn.responseCode) {
                200 -> {}
                403, 404 -> error("Cboe has no options chain for \"$ticker\"")
                else -> error("Cboe returned HTTP ${conn.responseCode}")
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(body)
            val data = root.getJSONObject("data")
            val spot = data.getDouble("current_price")
            val arr = data.getJSONArray("options")
            val out = ArrayList<Opt>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val m = SYMBOL.find(o.optString("option")) ?: continue
                val oi = o.optDouble("open_interest", 0.0)
                val g = o.optDouble("gamma", 0.0)
                val iv = o.optDouble("iv", 0.0)
                if (oi.isNaN() || g.isNaN() || oi <= 0.0 || g <= 0.0) continue
                out += Opt(
                    expiry = LocalDate.parse(m.groupValues[2], DATE),
                    isCall = m.groupValues[3] == "C",
                    strike = m.groupValues[4].toDouble() / 1000.0,
                    gamma = g,
                    oi = oi,
                    iv = if (iv.isNaN()) 0.0 else iv,
                )
            }
            if (out.isEmpty()) error("Chain for $ticker has no open interest")
            return Chain(spot, root.optString("timestamp"), out)
        } finally {
            conn.disconnect()
        }
    }

    // ---- offline cache (last good snapshot per ticker) ----

    private fun cacheFile(ticker: String, dir: File) = File(dir, "chain_$ticker.txt")

    private fun save(ticker: String, c: Chain, dir: File) {
        val tmp = File(dir, "chain_$ticker.tmp")
        tmp.bufferedWriter().use { w ->
            w.write("${c.spot}|${c.timestamp}\n")
            for (o in c.options) {
                w.write("${o.expiry.toEpochDay()}|${if (o.isCall) "C" else "P"}|${o.strike}|${o.gamma}|${o.oi}|${o.iv}\n")
            }
        }
        tmp.renameTo(cacheFile(ticker, dir))
    }

    suspend fun loadCached(ticker: String, dir: File): Chain? = withContext(Dispatchers.IO) {
        val f = cacheFile(ticker, dir)
        if (!f.exists()) return@withContext null
        runCatching {
            f.bufferedReader().use { r ->
                val head = r.readLine().split("|", limit = 2)
                val out = ArrayList<Opt>()
                r.forEachLine { line ->
                    val p = line.split("|")
                    if (p.size == 6) out += Opt(
                        LocalDate.ofEpochDay(p[0].toLong()), p[1] == "C",
                        p[2].toDouble(), p[3].toDouble(), p[4].toDouble(), p[5].toDouble(),
                    )
                }
                Chain(head[0].toDouble(), head.getOrElse(1) { "" }, out, fromCache = true)
            }
        }.getOrNull()
    }
}
