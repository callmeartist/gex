package com.shahid.gex

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiState(
    val ticker: String = "SPX",
    val filter: ExpFilter = ExpFilter.ZERO,
    val loading: Boolean = false,
    val error: String? = null,
    val chain: Chain? = null,
    val result: GexResult? = null,
)

class GexViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("gex", 0)
    private val cacheDir = app.filesDir

    private val _state = MutableStateFlow(
        UiState(
            ticker = prefs.getString("ticker", "SPX") ?: "SPX",
            filter = runCatching { ExpFilter.valueOf(prefs.getString("filter", "ZERO")!!) }.getOrDefault(ExpFilter.ZERO),
        )
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            showCached()
            refresh()
            while (true) {
                delay(60_000)
                refresh()
            }
        }
    }

    private suspend fun compute(c: Chain, f: ExpFilter) =
        withContext(Dispatchers.Default) { GexCalculator.compute(c, f) }

    private suspend fun showCached() {
        val t = _state.value.ticker
        val c = CboeRepository.loadCached(t, cacheDir) ?: return
        val r = compute(c, _state.value.filter)
        _state.update { if (it.ticker == t && it.chain == null) it.copy(chain = c, result = r) else it }
    }

    fun setTicker(raw: String) {
        val t = raw.trim().uppercase()
        if (t.isEmpty() || t == _state.value.ticker) return
        prefs.edit().putString("ticker", t).apply()
        _state.update { it.copy(ticker = t, chain = null, result = null, error = null) }
        viewModelScope.launch { showCached(); refresh() }
    }

    fun setFilter(f: ExpFilter) {
        prefs.edit().putString("filter", f.name).apply()
        _state.update { it.copy(filter = f) }
        val c = _state.value.chain ?: return
        viewModelScope.launch {
            val r = compute(c, f)
            _state.update { if (it.filter == f) it.copy(result = r) else it }
        }
    }

    fun refreshNow() { viewModelScope.launch { refresh() } }

    private suspend fun refresh() {
        val t = _state.value.ticker
        _state.update { it.copy(loading = true, error = null) }
        try {
            val chain = CboeRepository.fetch(t, cacheDir)
            val r = compute(chain, _state.value.filter)
            _state.update { if (it.ticker == t) it.copy(chain = chain, result = r, loading = false) else it }
        } catch (e: Exception) {
            _state.update {
                if (it.ticker == t) it.copy(loading = false, error = e.message ?: "Failed to load $t") else it
            }
        }
    }
}
