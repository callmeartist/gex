package com.shahid.gex

import java.time.LocalDate

data class Opt(
    val expiry: LocalDate,
    val isCall: Boolean,
    val strike: Double,
    val gamma: Double, // CBOE's own per-contract gamma
    val oi: Double,
    val iv: Double,
)

data class Chain(
    val spot: Double,
    val timestamp: String,
    val options: List<Opt>,
    val fromCache: Boolean = false,
)

enum class ExpFilter(val label: String) {
    ZERO("0DTE / nearest"),
    WEEK("Within 7d"),
    ALL("All expiries"),
}

/** call >= 0, put <= 0 : dollars of delta-hedge per 1% move in the underlying. */
data class StrikeGex(val strike: Double, val call: Double, val put: Double) {
    val net get() = call + put
}

data class ProfilePt(val spot: Double, val gex: Double)

data class GexResult(
    val spot: Double,
    val strikes: List<StrikeGex>, // chart window only
    val totalGex: Double,         // at current spot, CBOE gamma
    val flip: Double?,            // zero crossing of re-priced GEX profile
    val callWall: Double?,
    val putWall: Double?,
    val profile: List<ProfilePt>,
)
