# GEX – Android gamma exposure app (personal use)

Kotlin + Jetpack Compose. Reads Cboe's delayed options chain directly
(cdn.cboe.com: open interest, IV and Cboe-computed gamma per contract), no backend.

## Shows
- Net GEX per 1% move (Cboe gamma x OI x 100 x spot^2 x 0.01; calls +, puts -)
- Gamma flip: total GEX re-priced with Black-Scholes (Cboe IV) over spot +-10%, zero crossing nearest spot
- Call wall / put wall
- GEX-by-strike chart (spot + flip lines) and a total-GEX-vs-spot profile curve
- Filters: 0DTE/nearest, within 7 days, all expiries
- SPX, SPY, QQQ, NDX, IWM or any optionable ticker; remembers last ticker/filter
- Auto-refresh every 60s, 3 retries on network errors, last good snapshot cached offline

## Build an installable APK
Android Studio -> open folder -> sync, then Build > Build APK(s)
(or `./gradlew assembleRelease`; release is signed with the debug key for sideloading).

## Data notes
- Quotes are delayed ~15 min; OI is the prior-day figure (all free GEX tools share this).
- True real-time needs a paid feed (Cboe LiveVol / DataShop, or a vendor like Tradier/Polygon).
- Dealer sign convention (long calls / short puts) is an assumption.
